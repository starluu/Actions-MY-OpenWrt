#!/bin/bash
#
# Copyright (c) 2019-2020 P3TERX <https://p3terx.com>
#
# This is free software, licensed under the MIT License.
# See /LICENSE for more information.
#
# https://github.com/P3TERX/Actions-OpenWrt
# File name: diy-part1.sh
# Description: OpenWrt DIY script part 1 (Before Update feeds)
#

# 删除原target.mk
rm -rf include/target.mk

# 下载target.mk
wget -P include https://github.com/x-wrt/x-wrt/raw/master/include/target.mk

# 删除原Makefile
rm -rf target/linux/x86/Makefile

# 下载Makefile
wget -P target/linux/x86 https://github.com/x-wrt/x-wrt/raw/master/target/linux/x86/Makefile

# 注释掉默认luci源
sed -i 's/^\(.*luci\)/#&/' feeds.conf.default

# 添加其他的luci源
sed -i '$a src-git luci https://github.com/guyezi/hello-luci.git' feeds.conf.default

# Add a feed source
sed -i '$a src-git Boos4721 https://github.com/Boos4721/OpenWrt-Packages.git' feeds.conf.default
